# Pulse Blast - Backend API

Node.js/Express REST API with MySQL database for the Pulse Blast WhatsApp campaign manager.

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

Copy `.env.example` to `.env` and update with your MySQL credentials:

```bash
cp .env.example .env
```

Edit `.env` with your database details:
```env
DB_HOST=localhost
DB_USER=faceso56_suporte
DB_PASSWORD=qI08Psb59vVEbHQSiZk8AN234
DB_NAME=faceso56_wats
DB_PORT=3306

JWT_SECRET=<generate-a-secure-random-string>
```

### 3. Set Up Database

Execute the SQL schema in your MySQL database:

**Option A: Using phpMyAdmin (Hostgator)**
1. Log into cPanel
2. Open phpMyAdmin
3. Select database `faceso56_wats`
4. Go to SQL tab
5. Copy/paste contents of `database/schema.sql`
6. Click "Go"

**Option B: Using MySQL CLI**
```bash
mysql -u faceso56_suporte -p faceso56_wats < database/schema.sql
```

### 4. Start Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

Server will start on `http://localhost:3001`

## 📡 API Endpoints

### Authentication
- `POST /api/auth/signup` - Create account
- `POST /api/auth/signin` - Login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/signout` - Logout

### Contacts
- `GET /api/contacts` - List all contacts
- `POST /api/contacts` - Create contact
- `POST /api/contacts/bulk` - Bulk import
- `PUT /api/contacts/:id` - Update contact
- `DELETE /api/contacts/:id` - Delete contact
- `GET /api/contacts/count` - Get count

### Categories
- `GET /api/categories` - List all categories
- `POST /api/categories` - Create category
- `PUT /api/categories/:id` - Update category
- `DELETE /api/categories/:id` - Delete category
- `POST /api/categories/:categoryId/contacts/:contactId` - Assign contact
- `DELETE /api/categories/:categoryId/contacts/:contactId` - Remove contact
- `GET /api/categories/:categoryId/contacts` - Get category contacts

### Campaigns
- `GET /api/campaigns` - List all campaigns
- `GET /api/campaigns/:id` - Get campaign
- `POST /api/campaigns/create-with-messages` - Create campaign
- `PUT /api/campaigns/:id` - Update campaign
- `DELETE /api/campaigns/:id` - Delete campaign
- `GET /api/campaigns/:id/messages` - Get campaign messages
- `PUT /api/campaigns/messages/:id` - Update message
- `GET /api/campaigns/stats/count` - Get campaign count
- `GET /api/campaigns/stats/sent` - Get sent messages count

## 🔒 Authentication

All endpoints except `/api/auth/signup` and `/api/auth/signin` require authentication.

Include the JWT token in requests:
```
Authorization: Bearer <your-jwt-token>
```

## 📦 Project Structure

```
backend/
├── database/
│   ├── db.js          # MySQL connection pool
│   └── schema.sql     # Database schema
├── middleware/
│   └── auth.js        # JWT authentication
├── routes/
│   ├── auth.js        # Authentication routes
│   ├── contacts.js    # Contacts routes
│   ├── categories.js  # Categories routes
│   └── campaigns.js   # Campaigns routes
├── .env               # Environment variables (not in git)
├── .env.example       # Environment template
├── package.json       # Dependencies
└── server.js          # Express app entry point
```

## 🛠️ Development

The API uses:
- **Express.js** - Web framework
- **MySQL2** - MySQL client
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **express-validator** - Input validation

## 🌐 Deployment

### Hostgator Deployment

1. Upload `backend` folder to your hosting
2. Configure Node.js application in cPanel
3. Set environment variables in cPanel interface
4. Install dependencies: `npm install`
5. Start application: `npm start`

### Environment Variables for Production

Update `.env` for production:
```env
NODE_ENV=production
FRONTEND_URL=https://yourdomain.com
PORT=3001
```

## 🔐 Security Notes

- Always use HTTPS in production
- Keep JWT_SECRET secure and random
- Use strong MySQL passwords
- Enable MySQL remote access only if needed
- Validate all user inputs
- Keep dependencies updated

## 🐛 Troubleshooting

**Database connection failed:**
- Check MySQL credentials in `.env`
- Verify MySQL server is running
- Check if database exists

**CORS errors:**
- Update `FRONTEND_URL` in `.env`
- Check frontend URL in CORS config

**Port already in use:**
- Change `PORT` in `.env`
- Or kill process: `npx kill-port 3001`

## 📝 License

MIT
