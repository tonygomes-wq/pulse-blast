import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../database/db.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all contacts
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [contacts] = await pool.query(
      `SELECT c.*, 
        GROUP_CONCAT(DISTINCT cat.id) as category_ids,
        GROUP_CONCAT(DISTINCT cat.name) as category_names,
        GROUP_CONCAT(DISTINCT cat.color) as category_colors
      FROM contacts c
      LEFT JOIN contact_categories cc ON c.id = cc.contact_id
      LEFT JOIN categories cat ON cc.category_id = cat.id
      WHERE c.user_id = ?
      GROUP BY c.id
      ORDER BY c.created_at DESC`,
      [req.user.id]
    );

    // Format the response to match Supabase structure
    const formattedContacts = contacts.map(contact => ({
      ...contact,
      categories: contact.category_ids ? contact.category_ids.split(',').map((id, index) => ({
        id,
        name: contact.category_names.split(',')[index],
        color: contact.category_colors.split(',')[index]
      })) : []
    }));

    // Remove temporary fields
    formattedContacts.forEach(c => {
      delete c.category_ids;
      delete c.category_names;
      delete c.category_colors;
    });

    res.json(formattedContacts);
  } catch (error) {
    console.error('Get contacts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create contact
router.post('/',
  authenticateToken,
  body('whatsapp').notEmpty(),
  body('name').optional().trim(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, whatsapp } = req.body;

    try {
      const [result] = await pool.query(
        'INSERT INTO contacts (user_id, name, whatsapp) VALUES (?, ?, ?)',
        [req.user.id, name || null, whatsapp]
      );

      const [contacts] = await pool.query('SELECT * FROM contacts WHERE id = ?', [result.insertId]);
      res.status(201).json(contacts[0]);
    } catch (error) {
      console.error('Create contact error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Bulk create contacts
router.post('/bulk', authenticateToken, async (req, res) => {
  const { contacts } = req.body;

  if (!Array.isArray(contacts) || contacts.length === 0) {
    return res.status(400).json({ error: 'Contacts array is required' });
  }

  try {
    const values = contacts.map(c => [req.user.id, c.name || null, c.whatsapp]);
    
    await pool.query(
      'INSERT INTO contacts (user_id, name, whatsapp) VALUES ?',
      [values]
    );

    res.status(201).json({ message: `${contacts.length} contacts imported successfully` });
  } catch (error) {
    console.error('Bulk create error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update contact
router.put('/:id',
  authenticateToken,
  body('whatsapp').optional(),
  body('name').optional().trim(),
  async (req, res) => {
    const { id } = req.params;
    const { name, whatsapp } = req.body;

    try {
      // Check ownership
      const [existing] = await pool.query('SELECT id FROM contacts WHERE id = ? AND user_id = ?', [id, req.user.id]);
      if (existing.length === 0) {
        return res.status(404).json({ error: 'Contact not found' });
      }

      const updates = [];
      const values = [];

      if (name !== undefined) {
        updates.push('name = ?');
        values.push(name || null);
      }
      if (whatsapp !== undefined) {
        updates.push('whatsapp = ?');
        values.push(whatsapp);
      }

      if (updates.length > 0) {
        values.push(id);
        await pool.query(`UPDATE contacts SET ${updates.join(', ')} WHERE id = ?`, values);
      }

      const [contacts] = await pool.query('SELECT * FROM contacts WHERE id = ?', [id]);
      res.json(contacts[0]);
    } catch (error) {
      console.error('Update contact error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Delete contact
router.delete('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM contacts WHERE id = ? AND user_id = ?', [id, req.user.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json({ message: 'Contact deleted successfully' });
  } catch (error) {
    console.error('Delete contact error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get contact count
router.get('/count', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.query('SELECT COUNT(*) as count FROM contacts WHERE user_id = ?', [req.user.id]);
    res.json({ count: result[0].count });
  } catch (error) {
    console.error('Count contacts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
