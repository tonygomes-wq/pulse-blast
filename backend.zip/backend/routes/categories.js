import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../database/db.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all categories
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [categories] = await pool.query(
      'SELECT * FROM categories WHERE user_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(categories);
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create category
router.post('/',
  authenticateToken,
  body('name').notEmpty().trim(),
  body('color').optional(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, color } = req.body;

    try {
      const [result] = await pool.query(
        'INSERT INTO categories (user_id, name, color) VALUES (?, ?, ?)',
        [req.user.id, name, color || '#10b981']
      );

      const [categories] = await pool.query('SELECT * FROM categories WHERE id = ?', [result.insertId]);
      res.status(201).json(categories[0]);
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ error: 'Category name already exists' });
      }
      console.error('Create category error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Update category
router.put('/:id',
  authenticateToken,
  body('name').optional().trim(),
  body('color').optional(),
  async (req, res) => {
    const { id } = req.params;
    const { name, color } = req.body;

    try {
      // Check ownership
      const [existing] = await pool.query('SELECT id FROM categories WHERE id = ? AND user_id = ?', [id, req.user.id]);
      if (existing.length === 0) {
        return res.status(404).json({ error: 'Category not found' });
      }

      const updates = [];
      const values = [];

      if (name !== undefined) {
        updates.push('name = ?');
        values.push(name);
      }
      if (color !== undefined) {
        updates.push('color = ?');
        values.push(color);
      }

      if (updates.length > 0) {
        values.push(id);
        await pool.query(`UPDATE categories SET ${updates.join(', ')} WHERE id = ?`, values);
      }

      const [categories] = await pool.query('SELECT * FROM categories WHERE id = ?', [id]);
      res.json(categories[0]);
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ error: 'Category name already exists' });
      }
      console.error('Update category error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Delete category
router.delete('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM categories WHERE id = ? AND user_id = ?', [id, req.user.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get category count
router.get('/count', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.query('SELECT COUNT(*) as count FROM categories WHERE user_id = ?', [req.user.id]);
    res.json({ count: result[0].count });
  } catch (error) {
    console.error('Count categories error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Assign contact to category
router.post('/:categoryId/contacts/:contactId', authenticateToken, async (req, res) => {
  const { categoryId, contactId } = req.params;

  try {
    // Verify ownership
    const [category] = await pool.query('SELECT id FROM categories WHERE id = ? AND user_id = ?', [categoryId, req.user.id]);
    const [contact] = await pool.query('SELECT id FROM contacts WHERE id = ? AND user_id = ?', [contactId, req.user.id]);

    if (category.length === 0 || contact.length === 0) {
      return res.status(404).json({ error: 'Category or contact not found' });
    }

    await pool.query(
      'INSERT IGNORE INTO contact_categories (contact_id, category_id) VALUES (?, ?)',
      [contactId, categoryId]
    );

    res.json({ message: 'Contact assigned to category' });
  } catch (error) {
    console.error('Assign contact error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Remove contact from category
router.delete('/:categoryId/contacts/:contactId', authenticateToken, async (req, res) => {
  const { categoryId, contactId } = req.params;

  try {
    await pool.query(
      'DELETE FROM contact_categories WHERE contact_id = ? AND category_id = ?',
      [contactId, categoryId]
    );

    res.json({ message: 'Contact removed from category' });
  } catch (error) {
    console.error('Remove contact error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get contacts by category
router.get('/:categoryId/contacts', authenticateToken, async (req, res) => {
  const { categoryId } = req.params;

  try {
    const [contacts] = await pool.query(
      `SELECT c.* FROM contacts c
       INNER JOIN contact_categories cc ON c.id = cc.contact_id
       WHERE cc.category_id = ? AND c.user_id = ?`,
      [categoryId, req.user.id]
    );

    res.json(contacts);
  } catch (error) {
    console.error('Get category contacts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
