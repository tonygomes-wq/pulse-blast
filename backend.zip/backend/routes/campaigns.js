import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../database/db.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all campaigns
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [campaigns] = await pool.query(
      'SELECT * FROM campaigns WHERE user_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(campaigns);
  } catch (error) {
    console.error('Get campaigns error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get campaign by ID
router.get('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    const [campaigns] = await pool.query(
      'SELECT * FROM campaigns WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (campaigns.length === 0) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    res.json(campaigns[0]);
  } catch (error) {
    console.error('Get campaign error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create campaign with messages
router.post('/create-with-messages',
  authenticateToken,
  body('campaign_name').notEmpty().trim(),
  body('message_template').notEmpty(),
  body('contacts').isArray(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { campaign_name, message_template, contacts } = req.body;
    const connection = await pool.getConnection();

    try {
      await connection.beginTransaction();

      // Create campaign
      const [campaignResult] = await connection.query(
        'INSERT INTO campaigns (user_id, name, message_template, total_contacts) VALUES (?, ?, ?, ?)',
        [req.user.id, campaign_name, message_template, contacts.length]
      );

      const campaignId = campaignResult.insertId;

      // Create messages
      if (contacts.length > 0) {
        const messageValues = contacts.map(c => [
          campaignId,
          c.contact_id,
          c.message_content
        ]);

        await connection.query(
          'INSERT INTO campaign_messages (campaign_id, contact_id, message_content) VALUES ?',
          [messageValues]
        );
      }

      await connection.commit();

      res.status(201).json({ id: campaignId });
    } catch (error) {
      await connection.rollback();
      console.error('Create campaign error:', error);
      res.status(500).json({ error: 'Server error' });
    } finally {
      connection.release();
    }
  }
);

// Update campaign
router.put('/:id',
  authenticateToken,
  async (req, res) => {
    const { id } = req.params;
    const updates = req.body;

    try {
      // Check ownership
      const [existing] = await pool.query('SELECT id FROM campaigns WHERE id = ? AND user_id = ?', [id, req.user.id]);
      if (existing.length === 0) {
        return res.status(404).json({ error: 'Campaign not found' });
      }

      const fields = [];
      const values = [];

      Object.keys(updates).forEach(key => {
        if (['name', 'message_template', 'status', 'sent_count', 'failed_count', 'started_at', 'completed_at'].includes(key)) {
          fields.push(`${key} = ?`);
          values.push(updates[key]);
        }
      });

      if (fields.length > 0) {
        values.push(id);
        await pool.query(`UPDATE campaigns SET ${fields.join(', ')} WHERE id = ?`, values);
      }

      const [campaigns] = await pool.query('SELECT * FROM campaigns WHERE id = ?', [id]);
      res.json(campaigns[0]);
    } catch (error) {
      console.error('Update campaign error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Delete campaign
router.delete('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM campaigns WHERE id = ? AND user_id = ?', [id, req.user.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    res.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    console.error('Delete campaign error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get campaign messages
router.get('/:id/messages', authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    // Verify campaign ownership
    const [campaigns] = await pool.query('SELECT id FROM campaigns WHERE id = ? AND user_id = ?', [id, req.user.id]);
    if (campaigns.length === 0) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    const [messages] = await pool.query(
      `SELECT cm.*, c.name as contact_name, c.whatsapp as contact_whatsapp
       FROM campaign_messages cm
       INNER JOIN contacts c ON cm.contact_id = c.id
       WHERE cm.campaign_id = ?
       ORDER BY cm.created_at ASC`,
      [id]
    );

    // Format to match Supabase structure
    const formattedMessages = messages.map(msg => ({
      ...msg,
      contact: {
        name: msg.contact_name,
        whatsapp: msg.contact_whatsapp
      }
    }));

    // Remove temporary fields
    formattedMessages.forEach(m => {
      delete m.contact_name;
      delete m.contact_whatsapp;
    });

    res.json(formattedMessages);
  } catch (error) {
    console.error('Get campaign messages error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update message status
router.put('/messages/:messageId',
  authenticateToken,
  async (req, res) => {
    const { messageId } = req.params;
    const updates = req.body;

    try {
      const fields = [];
      const values = [];

      Object.keys(updates).forEach(key => {
        if (['status', 'error_message', 'sent_at'].includes(key)) {
          fields.push(`${key} = ?`);
          values.push(updates[key]);
        }
      });

      if (fields.length > 0) {
        values.push(messageId);
        await pool.query(`UPDATE campaign_messages SET ${fields.join(', ')} WHERE id = ?`, values);
      }

      const [messages] = await pool.query('SELECT * FROM campaign_messages WHERE id = ?', [messageId]);
      res.json(messages[0]);
    } catch (error) {
      console.error('Update message error:', error);
      res.status(500).json({ error: 'Server error' });
    }
  }
);

// Get campaign count
router.get('/stats/count', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.query('SELECT COUNT(*) as count FROM campaigns WHERE user_id = ?', [req.user.id]);
    res.json({ count: result[0].count });
  } catch (error) {
    console.error('Count campaigns error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get sent messages count
router.get('/stats/sent', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.query(
      `SELECT COUNT(*) as count FROM campaign_messages cm
       INNER JOIN campaigns c ON cm.campaign_id = c.id
       WHERE c.user_id = ? AND cm.status = 'sent'`,
      [req.user.id]
    );
    res.json({ count: result[0].count });
  } catch (error) {
    console.error('Count sent messages error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
